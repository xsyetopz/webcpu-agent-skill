# WebCPU EASEL.js Agent Instructions

Use this repository to build, install, and package the `webcpu-easel` skill for AI coding agents.

## First Read

1. Read `llms.txt` for the concise repo map, or `llms-full.txt` for full context.
2. Read `source/skills/webcpu-easel/body.md` for the agent execution contract.
3. Use `source/skills/webcpu-easel/REFERENCE.md` before generating EASEL.js code.
4. Verify symbols in `source/skills/webcpu-easel/reference/api-index.md` and shapes in `source/skills/webcpu-easel/reference/class-signatures.md`.

## Agent Contract

- Baseline package: `@xsyetopz/easel@0.5.0`.
- Prefer source-grounded code over memory.
- If a requested API is absent from references and installed declarations, answer `UNKNOWN` with the missing symbol or behavior.
- Do not invent WebGL, WebGPU, THREE.js, or CreateJS EaselJS APIs.
- EASEL.js rendering requires browser DOM canvas. Deno can typecheck, bundle, and serve browser code; plain Deno CLI is not a headless renderer.
- Keep generated platform outputs out of source. `source/skills/webcpu-easel/` is canonical.

## Build and Validate

```bash
bun install
bun run check
bun run clean && bun run validate:source
```

`bun run check` extracts API docs, generates platform skill files, generates agent instruction surfaces, generates LLM context, packages bundles, validates package output, runs Biome, runs TypeScript, and runs optional Deno checks.

After editing this file, run:

```bash
bun run generate:agents
```

## Generated Outputs

- `.build/generated/` -- generated platform skill files.
- `.build/llms/` -- generated LLM aggregate context.
- `dist/` -- self-contained installable bundles.
- `.agents/plugins/marketplace.json` -- hosted Codex marketplace metadata.
- `CLAUDE.md`, `GEMINI.md`, `.rules`, `.github/copilot-instructions.md`, `.cursor/rules/webcpu-easel.mdc`, `.aiassistant/rules/`, `.junie/AGENTS.md`, `.clinerules/`, `.augment/rules/`, `.claude-plugin/`, `.agents/plugins/`, `plugins/webcpu-agent-skill/`, and `docs/agent-platforms.md` -- generated from this file.

Generated paths and generated instruction surfaces are artifacts. Do not edit them by hand.

## Install Targets

- Codex: package plugin under `dist/codex/plugin/webcpu-agent-skill`; hosted marketplace at `.agents/plugins/marketplace.json`.
- Claude Code: package skill under `dist/claude/skills/webcpu-easel`; hosted marketplace at `.claude-plugin/marketplace.json`.
- OpenCode: package skill under `dist/opencode/templates/skills/webcpu-easel`.
- GitHub Copilot: repo instructions at `.github/copilot-instructions.md`; packaged skills under `dist/copilot`.
- Gemini CLI: wrapper at `GEMINI.md`.
- Cursor: project rule at `.cursor/rules/webcpu-easel.mdc`.
- Zed: project rule at `.rules`.
- JetBrains AI Assistant / Junie: `.aiassistant/rules/webcpu-easel.md` and `.junie/AGENTS.md`.
- Cline: `.clinerules/00-webcpu-easel.md`.
- KiloCode Legacy: package skill under `dist/kilocode/skills/webcpu-easel`; installer copies to `.kilocode/skills/webcpu-easel`.
- Augment: `.augment/rules/webcpu-easel.md`.
- Amp and compatible Neovim workflows: root `AGENTS.md`.

## Repo Editing Rules

- Prefer small edits to canonical source files.
- Do not duplicate references, examples, or templates into platform directories under source.
- Add validation when adding a new install surface or generated artifact.
- Run `bun run check` before committing substantial changes.
